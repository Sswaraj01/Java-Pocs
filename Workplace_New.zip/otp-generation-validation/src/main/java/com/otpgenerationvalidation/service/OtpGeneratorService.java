package com.otpgenerationvalidation.service;

import java.util.Date;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.otpgenerationvalidation.Entity.OtpEntity;
import com.otpgenerationvalidation.bean.OtpDetails;
import com.otpgenerationvalidation.repository.OtpRepository;


@Service
public class OtpGeneratorService {

	@Autowired
	private OtpRepository otpRepo;
	

	public boolean generateOtp(String userid) {
		OtpEntity otpEntity= new OtpEntity();
		otpEntity.setUserId(userid);
		otpEntity.setOtpValue(getRandomNumberInts());
		otpEntity.setCreationTime(new Date());
		otpEntity.setExpireTime(new Date(System.currentTimeMillis()+5*60*1000));
		if(otpRepo.save(otpEntity)!=null) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean validateOtp(OtpDetails otpdetails) {
		OtpEntity otpEntity=otpRepo.findByUserId(otpdetails.getUserId());
		if(otpEntity!=null) {
			if (otpdetails.getOtpValue()==otpEntity.getOtpValue()) {
				return true;
			}
		}
		return false;
	}
		
	



	private int getRandomNumberInts(){
		int min=100000;
		int max=999999;
		Random random = new Random();
		return random.ints(min,(max+1)).findFirst().getAsInt();
	}





}
