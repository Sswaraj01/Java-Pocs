package com.otpgenerationvalidation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.otpgenerationvalidation.Entity.OtpEntity;

@Repository
public interface OtpRepository extends JpaRepository<OtpEntity, Long>{

	@Query("SELECT o FROM OtpEntity o WHERE o.userId = :userId and expireTime > CURRENT_TIMESTAMP()")
	OtpEntity findByUserId(@Param("userId") String userId);

}
