package com.otpgenerationvalidation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.otpgenerationvalidation.bean.OtpGeneratorResBean;
import com.otpgenerationvalidation.service.OtpGeneratorService;

@RestController
public class OtpGeneratorController {

	@Autowired
	private OtpGeneratorService otpGenService;

	@RequestMapping(value="/generateOtp/{userid}")
	public ResponseEntity<OtpGeneratorResBean> generateOtp(@PathVariable("userid") String userid){
		OtpGeneratorResBean otpGeneratorResBean=new OtpGeneratorResBean();
		if(otpGenService.generateOtp(userid)) {
			otpGeneratorResBean.setStatus_code("200");
			otpGeneratorResBean.setMessage("Otp Generated");
		}
		else {
			otpGeneratorResBean.setStatus_code("400");
			otpGeneratorResBean.setMessage("Otp not generated");
		}
		return new ResponseEntity<OtpGeneratorResBean>(otpGeneratorResBean, HttpStatus.OK);
	}

}
