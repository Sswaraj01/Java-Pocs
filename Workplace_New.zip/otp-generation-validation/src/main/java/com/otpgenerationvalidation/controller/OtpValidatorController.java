package com.otpgenerationvalidation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.otpgenerationvalidation.bean.OtpDetails;
import com.otpgenerationvalidation.bean.OtpGeneratorResBean;
import com.otpgenerationvalidation.service.OtpGeneratorService;

@RestController
public class OtpValidatorController {

	@Autowired
	private OtpGeneratorService otpGenService;

	@RequestMapping(value="/validateOtp",method=RequestMethod.POST)
	public ResponseEntity<OtpGeneratorResBean> generateOtp(@RequestBody OtpDetails otpdetails){
		OtpGeneratorResBean otpGeneratorResBean=new OtpGeneratorResBean();
		if(otpGenService.validateOtp(otpdetails)) {
			otpGeneratorResBean.setStatus_code("200");
			otpGeneratorResBean.setMessage("Otp successfully validated");
		}
		else {
			otpGeneratorResBean.setStatus_code("400");
			otpGeneratorResBean.setMessage("Otp not validated or incorrect");
		}
		return new ResponseEntity<OtpGeneratorResBean>(otpGeneratorResBean, HttpStatus.OK);
	}
}
