package com.otpgenerationvalidation.Entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="OTP_MASTER")
public class OtpEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="OTP_ID")
	private long otpId;
	
	@Column(name="USER_ID")
	private String userId;
	
	@Column(name="OTP_VALUE")
	private int otpValue;
	
	@Column(name="CREATION_TIME")
	private Date creationTime;
	
	@Column(name="EXPIRE_TIME")
	private Date expireTime;
	
	public OtpEntity() {
		super();
	}

	public OtpEntity(long otpId, String userId, int otpValue, Date creationTime, Date expireTime) {
		super();
		this.otpId = otpId;
		this.userId = userId;
		this.otpValue = otpValue;
		this.creationTime = creationTime;
		this.expireTime = expireTime;
	}

	public long getOtpId() {
		return otpId;
	}

	public void setOtpId(long otpId) {
		this.otpId = otpId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getOtpValue() {
		return otpValue;
	}

	public void setOtpValue(int otpValue) {
		this.otpValue = otpValue;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public Date getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(Date expireTime) {
		this.expireTime = expireTime;
	}

	@Override
	public String toString() {
		return "OtpEntity [otpId=" + otpId + ", userId=" + userId + ", otpValue=" + otpValue + ", creationTime="
				+ creationTime + ", expireTime=" + expireTime + "]";
	}

	
	
	

}
