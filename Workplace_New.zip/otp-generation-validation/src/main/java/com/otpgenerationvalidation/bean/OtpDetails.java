package com.otpgenerationvalidation.bean;

public class OtpDetails {

	private String userId;

	private int otpValue;

	public OtpDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OtpDetails(String userId, int otpValue) {
		super();
		this.userId = userId;
		this.otpValue = otpValue;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getOtpValue() {
		return otpValue;
	}

	public void setOtpValue(int otpValue) {
		this.otpValue = otpValue;
	}

	@Override
	public String toString() {
		return "OtpDetails [userId=" + userId + ", otpValue=" + otpValue + "]";
	}
	
	
}
