package com.test;

public class YMLgenerator {

}
