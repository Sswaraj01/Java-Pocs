package com.caeser;

public class CaeserCipher {

	static StringBuffer encrypt(String text,int s) {
		StringBuffer str=new StringBuffer();
		for(int i=0;i<text.length();i++) {
			if(Character.isUpperCase(text.charAt(i))) {
				char ch = (char)(((int)text.charAt(i) + s - 65) % 26 + 65); 
				str.append(ch); 
			}else {
				char ch = (char)(((int)text.charAt(i) +s - 97) % 26 + 97); 
				str.append(ch); 
			}
		}
		return str;
	}
	static StringBuffer decrypt(String text,int s) {
		StringBuffer str=new StringBuffer();
		for(int i=0;i<text.length();i++) {
			if(Character.isUpperCase(text.charAt(i))) {
				char ch = (char)(((int)text.charAt(i) - (s-26) - 65) % 26 + 65); 
				str.append(ch); 
			}else {
				char ch = (char)(((int)text.charAt(i) - (s-26) - 97) % 26 + 97); 
				str.append(ch); 
			}
		}
		return str;
	}

	public static void main(String[] args) {
		String text = "xyz"; 
        int s = 3; 
        System.out.println("Text  : " + text); 
        System.out.println("Shift : " + s); 
        System.out.println("Cipher:encrypt: " + encrypt(text, s)); 
        System.out.println("Cipher:decrypt: " + decrypt(text, s)); 


	}

}
